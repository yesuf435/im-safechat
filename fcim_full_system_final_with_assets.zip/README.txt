部署说明：
1. 解压后将 im/ 拷贝至 /www/wwwroot/fcim_full_7005_7006/
2. 将 server/ 拷贝至 /mnt/data/opt/im-system/
3. 后端：cd server && npm install && node server.js &
4. 导入数据库 schema.sql
5. 访问 http://你的IP:7005/im/index.html
