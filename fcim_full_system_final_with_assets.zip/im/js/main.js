
let ws = new WebSocket("ws://localhost:6655");
ws.onmessage = function(event) {
    const box = document.getElementById("chat-box");
    const msg = document.createElement("div");
    msg.textContent = event.data;
    box.appendChild(msg);
    box.scrollTop = box.scrollHeight;
};
function sendMessage() {
    const input = document.getElementById("msgInput");
    if (input.value.trim()) {
        ws.send(input.value);
        input.value = "";
    }
}
